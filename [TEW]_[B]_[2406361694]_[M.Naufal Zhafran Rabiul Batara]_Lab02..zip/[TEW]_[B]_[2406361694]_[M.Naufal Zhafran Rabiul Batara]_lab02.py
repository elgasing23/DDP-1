#Meminta input npm kepada user
npm = int(input("Masukkan NPM: " ))

#mencetak konversi npm(desimal) ke binary dan hexadecimal
print(f"Nilai binary dari NPM {npm} adalah {bin(npm)}")
print(f"Nilai hexadecimal dari NPM {npm} adalah {hex(npm)}")

#meminta input harga barang dalam binary dan jumlah uang dalam hexadecimal
harga_barang = input("Masukkan harga barang (dalam binary): ")
jumlah_uang = input("Masukkan jumlah uang (dalam hexadecimal: ")

#konversi harga barang dan jumlah uang ke desimal
harga_barang = int(harga_barang, 2)
jumlah_uang = int(jumlah_uang, 16)

#mencetak kesimpulan
if harga_barang > jumlah_uang:
    print(f'Uang kurang karena {harga_barang} lebih besar dari {jumlah_uang}!')
elif jumlah_uang > harga_barang:
    print(f'Uang kelebihan karena {harga_barang} lebih kecil dari {jumlah_uang}!')
elif jumlah_uang == harga_barang:
    print(f'Uang pas karena uang dan barang bernilai {harga_barang}!')
    
