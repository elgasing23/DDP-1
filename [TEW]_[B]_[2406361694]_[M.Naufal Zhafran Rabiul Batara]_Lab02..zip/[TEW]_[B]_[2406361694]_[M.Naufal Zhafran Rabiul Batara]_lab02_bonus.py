import turtle as t
#mengatur kecepatan penggambaran
t.speed(1)

#meminta input jumlah sisi dalam angka biner
binary = input("Masukkan bilangan binary: ")
#mengkonversi biner ke desimal
desimal = int(binary, 2)

#membatasi jumlah segi min 3 max 6
if desimal < 3 or desimal > 6:
    print("Nilai x harus di antara 3 dan 6.")

#menghitung sudut segi-x
sudut = 360 / desimal

for i in range (desimal):
    t.forward(100) #panjang sisi
    t.right(sudut) #belok sebesar sudut x

t.done #selesaikan gambar


