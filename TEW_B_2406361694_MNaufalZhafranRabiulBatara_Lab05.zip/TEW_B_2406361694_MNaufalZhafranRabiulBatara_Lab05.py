import math #import math dari library (untuk operasi rumus log dan ceiling)

def hitung_presentase_keuntungan_atau_kerugian(): #fungsi  hitung presentase untung/rugi
    try:  #membuat try untuk mendeteksi error
        pemasukan = int(input("Masukkan pemasukan: "))
        pengeluaran = int(input("Masukkan pengeluaran: "))
        if  pemasukan > pengeluaran:
            keuntungan =  (pemasukan - pengeluaran) / pengeluaran*100
            print(f"Hasil Penghitungan Iterasi {count}:\nHasil Keuntungan atau kerugian: Keuntungan sebesar {keuntungan:.2f}%", file=my_file) #menulis keuntungan di file 
            print(f"Hasil penghitungan iterasi ke-{count} telah ditulis ke dalam file '{nama_file}'.\n")
            my_file.close()
        elif pemasukan < pengeluaran:
            kerugian = (pengeluaran - pemasukan) / pemasukan*100
            print(f"Hasil Penghitungan Iterasi {count}:\nHasil Keuntungan atau kerugian: Kerugian sebesar {kerugian:.2f}%", file=my_file)  #menulis kerugian di file

            print(f"Hasil penghitungan iterasi ke-{count} telah ditulis ke dalam file '{nama_file}'.\n")
            my_file.close()
        elif pemasukan == pengeluaran:
            print(f"Hasil Penghitungan Iterasi {count}:\nHasil Keuntungan atau kerugian: Tidak ada keuntungan atau kerugian", file=my_file)  #menulis tidak ada keuntungan atau kerugian di file
            print(f"Hasil penghitungan iterasi ke-{count} telah ditulis ke dalam file '{nama_file}'.\n")
            my_file.close()
    except ZeroDivisionError: #jika terdeteksi zerodevisionerror 
        print(f"Hasil Penghitungan Iterasi {count}:\nHasil Keuntungan atau kerugian: ZeroDivisionError: Pemasukan atau pengeluaran tidak boleh 0.", file=my_file)
        print(f"Hasil penghitungan iterasi ke-{count} telah ditulis ke dalam file '{nama_file}'.\n")
        my_file.close()
    except  ValueError:  #jika terdeteksi valueerror
        print(f"Hasil Penghitungan Iterasi {count}:\nHasil Keuntungan atau kerugian: ValueError: Pemasukan dan pengeluaran harus berupa angka yang valid.", file=my_file)
        print(f"Hasil penghitungan iterasi ke-{count} telah ditulis ke dalam file '{nama_file}'.\n")
        my_file.close()
    finally: #tetap melanjutkan kode walaupun  terjadi error
        None

def hitung_waktu_target_tabungan(): #fungsi hitung waktu targe tabungan
    try:
        tabungan_awal = int(input("Masukkan tabungan awal: "))
        bunga = int(input("Masukkan bunga tahunan (%): "))
        target_tabungan = int(input("Masukkan target tabungan: "))
        lama_tahun = math.log(target_tabungan/tabungan_awal) / math.log(1+ bunga/100) #rumus lama tahun
        lama_tahun = math.ceil(lama_tahun) #membulatkan keatas lama tahun
        print(f"Hasil Penghitungan Iterasi {count}:\nHasil Pergi ke Bank: Jumlah tahun untuk mencapai target: {lama_tahun} tahun", file=my_file) #menulis jumlah tahun di file
        print(f"Hasil penghitungan iterasi ke-{count} telah ditulis ke dalam file '{nama_file}'.\n")
        my_file.close()
    except ZeroDivisionError: #jika terdeteksi zero division error
        print(f"Hasil Penghitungan Iterasi {count}:\nHasil Pergi ke Bank: Jumlah tahun untuk mencapai target: ZeroDivisionError: Pemasukan atau pengeluaran tidak boleh 0.", file=my_file)
        print(f"Hasil penghitungan iterasi ke-{count} telah ditulis ke dalam file '{nama_file}'.\n")
        my_file.close()
    except  ValueError: #jika terdeteksi value error
        print(f"Hasil Penghitungan Iterasi {count}:\nHasil Pergi ke Bank: Jumlah tahun untuk mencapai target: ValueError: Pemasukan dan pengeluaran harus berupa angka yang valid.", file=my_file)
        print(f"Hasil penghitungan iterasi ke-{count} telah ditulis ke dalam file '{nama_file}'.\n")
        my_file.close() 
    finally:
        None


def main(): #fungsi utama
    global my_file, count, nama_file, my_file #membuat  variabel dapat diakses diluar  fungsi
    count = 0 #fungsi untuk menghitung jumlah file yang dibuat
    while True:  #membuat loop yang tidak akan berhenti sampai user memasukkan n
        jawaban = input("Apakah Anda ingin menghitung keuangan? (y/n): ")
        if jawaban == 'y':
            print('''Pilihlah opsi yang anda inginkan: 
    1. Menghitung persentase keuntungan atau kerugian. 
    2. Menghitung ekspektasi lama tahun untuk mencapai target tabungan.''')
            opsi = int(input("Masukkan pilihan anda (1/2): "))
            if opsi == 1:
                count += 1
                nama_file = f'hasil_perhitungan_{count}'
                my_file = open(f'{nama_file}.txt', 'w') #membuka file dengan mode read
                hitung_presentase_keuntungan_atau_kerugian() #memanggil fungsi hitung presentase keuntungan/kerugian
            elif opsi == 2:
                count += 1
                nama_file = f'hasil_perhitungan_{count}'
                my_file = open(f'{nama_file}.txt', 'w') #membuka file dengan mode read
                hitung_waktu_target_tabungan() #memanggil fungsi waktu target tabungan
            else:
                print("Invalid input")
        elif jawaban == 'n':
            print('Sampai jumpa di penghitungan keuangan berikutnya :( ')
            break
        else:
            print("Opsi tidak valid!\n")

    

if __name__ ==  "__main__":
    main()
