kalimat = input('Masukkan kalimat: ')
kalimat = kalimat.strip()

vokal = 'aiueo'
kalimat_konversi = ''

for i in kalimat:
    if i in vokal:
        kalimat_konversi += i.upper()
    elif i not in vokal:
        kalimat_konversi += i

jumlah_kata = 0
spasi = ' '
for i in kalimat:
    if i in spasi:
        jumlah_kata += 1
    elif i not in spasi:
        None

jumlah_vokal = 0
jumlah_nonvokal = 0
for i in kalimat:
    if i in vokal:
        jumlah_vokal += 1
    elif i not in vokal and i not in spasi:
        jumlah_nonvokal += 1
    

index = 0
space = 0
jumlah_awalakhir = 0

for index in range(len(kalimat)):
    i = kalimat[index]
    bukan_angka = i.isalpha()

    if bukan_angka:
        continue
    
    i = kalimat[index]
    if i == spasi:
        space += 1
        if space == 1 and kalimat[index - 1] not in vokal and kalimat[0] not in vokal:
            jumlah_awalakhir += 1
        elif space != 1 and kalimat[index - 1] not in vokal and kalimat[index + 1] not in vokal:
            jumlah_awalakhir += 1
if kalimat[-1] not in vokal and kalimat[0] not in vokal and bukan_angka:
    jumlah_awalakhir += 1


print(f"Kalimat asli             :{kalimat}")
print(f'Kalimat konversi         :{kalimat_konversi}')
print(f'Jumlah kata              :{jumlah_kata}')
print(f'Jumlah huruf vokal       :{jumlah_vokal}')
print(f'Jumlah huruf non-vokal   :{jumlah_nonvokal}')
print(f'Jumlah kata yang diawali dan diakhiri huruf non-vokal   :{jumlah_awalakhir}')







        



