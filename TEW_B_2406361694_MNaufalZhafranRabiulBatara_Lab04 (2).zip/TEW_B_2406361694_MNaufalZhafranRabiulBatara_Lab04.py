def print_title():
    print(r"   _____  ____   ____  ______ ____ ____   ______")
    print(r"  / ___/ / __ \ / __ \/_  __//  _// __ \ / ____/")
    print(r"  \__ \ / /_/ // / / / / /   / / / /_/ // __/   ")
    print(r" ___/ // ____// /_/ / / /  _/ / / ____// /___   ")
    print(r"/____//_/     \____/ /_/  /___//_/    /_____/   ")





def artist():
    
    while True:
        name = input("Enter artist name (q for quit): ").lower()
        if name == 'q':
            break
        print(f'------------------------------\nArtist: {name}')
        try:
            artist_name = open(f'{name}.csv', 'r')
            jumlah_lagu = 0
            for i in artist_name:
                jumlah_lagu += 1
            jumlah_lagu = jumlah_lagu - 1
            print(f"Show TOP 10 from {jumlah_lagu} songs")
            angka = 1
            artist_name = open(f'{name}.csv', 'r')
            for i in range(11):
                data = artist_name.readline()
                if i == 0:
                    continue
                data_split =  data.split(',')
                print(f'({angka}) {data_split[2]}')
                angka += 1
        
        except FileNotFoundError:
            print('Artist not found!')


        artist_name = open(f'{name}.csv', 'r')
        artis = artist_name.read()
        while True:
            print('-----------------------------')
            song = input(f"Enter song name (q for quit): ").lower()
            print('-----------------------------')
            if song == 'q':
                break
            if song in artis:
                artist_name = open(f'{name}.csv', 'r')
                artis = artist_name.read()
                baris = 0  
                for i in artist:
                    artist_name = open(f'{name}.csv', 'r')
                    data  = artist_name.readline()
                    if song in data:
                        data_split = data.split(",")
                        break
                    else:
                        None 
                    baris += 1  
            print(f'Title: {data_split[2]}\nAlbum: {data_split[3]}\nYear: {data_split[4]}\nDate: {data_split[5]}')
            print(f'Lyrics:  \n{data_split[6]}\n')

def main():
    print_title()
    artist()
    print("-"*30)
    print("Thank you for using Spotipe. See you next time!")

main()

        


     



        
            
            










print_title()
artist()